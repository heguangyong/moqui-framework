---
name: moqui
description: Moqui Framework enterprise application development with intelligent supply-demand platform - comprehensive local project documentation
---

# Moqui Framework & 智能供需平台开发技能

基于 Moqui Framework 和智能供需平台项目的综合开发技能，包含官方文档和本地项目文档。

## When to Use This Skill

此技能适用于以下场景：
- 开发 Moqui Framework 应用
- 智能供需平台功能开发
- Telegram Bot 集成
- AI 服务集成（智谱AI GLM-4/GLM-4V）
- JWT 认证系统实现
- Vue3 + Quasar2 前端开发
- HiveMind/POP/Marble 平台集成
- MCP (Model Context Protocol) 调试
- 多模态AI应用开发

## 项目架构概览

### 技术栈
- **后端**: Moqui Framework (Java/Groovy)
- **前端**: Vue3 + Quasar2
- **AI集成**: 智谱AI (GLM-4/GLM-4V)
- **消息平台**: Telegram Bot API
- **认证**: JWT (JSON Web Tokens)
- **数据库**: 支持多种数据库 (MySQL, PostgreSQL, etc.)

### 核心组件
- **moqui-marketplace**: 供需平台核心组件
- **moqui-mcp**: MCP集成组件
- **moqui-hivemind**: HiveMind项目管理集成
- **AI Services**: 多模态AI服务接口

## 核心功能模块

### 1. 供需撮合系统
- `/supply` - 发布供应信息
- `/demand` - 发布需求信息
- `/match` - 智能撮合匹配
- 多模态消息处理（文本、图像、语音）

### 2. 项目管理集成
- HiveMind 任务管理
- POP 电商平台集成
- Marble ERP 系统整合

### 3. AI 智能服务
- 智谱AI GLM-4 文本处理
- GLM-4V 图像理解
- 智能需求分析
- 自动化匹配推荐

## 开发阶段状态

### ✅ Phase 0 - 已完成
- 多模态AI平台集成
- JWT认证系统实施
- Vue3+Quasar2技术栈升级
- Chrome MCP调试工具链建立

### 🔄 Phase 1 - 进行中
- Telegram MVP闭环实现
- 供需撮合核心功能
- 多模态消息处理优化

### 📋 后续阶段
- **Phase 2**: HiveMind项目管理集成
- **Phase 3**: POP电商平台集成
- **Phase 4**: Marble ERP深度整合

## Quick Reference - 开发模式

### Moqui 实体操作
```groovy
// 创建实体记录
ec.entity.makeValue("YourEntity")
    .set("field1", value1)
    .set("field2", value2)
    .create()

// 查询实体
def entityList = ec.entity.find("YourEntity")
    .condition("field1", value1)
    .list()
```

### 服务定义
```xml
<service verb="create" noun="Supply" authenticate="true">
    <in-parameters>
        <parameter name="title" required="true"/>
        <parameter name="description"/>
        <parameter name="category"/>
    </in-parameters>
    <out-parameters>
        <parameter name="supplyId"/>
    </out-parameters>
    <actions>
        <!-- 服务逻辑 -->
    </actions>
</service>
```

### Telegram Bot 集成
```groovy
// Bot 消息处理
def processSupplyCommand(String chatId, String messageText) {
    def result = ec.service.sync().name("marketplace.SupplyServices.create#Supply")
        .parameters([title: extractTitle(messageText),
                    description: extractDescription(messageText)])
        .call()

    sendTelegramMessage(chatId, "供应信息已创建: ${result.supplyId}")
}
```

### AI 服务调用
```groovy
// 智谱AI 调用
def aiResponse = ec.service.sync().name("ai.ZhipuServices.call#GLM4")
    .parameters([
        model: "glm-4",
        messages: messages,
        temperature: 0.7
    ])
    .call()
```

### JWT 认证
```groovy
// JWT 令牌生成
def token = ec.service.sync().name("auth.JwtServices.generate#Token")
    .parameters([
        userId: userId,
        expirationMinutes: 60
    ])
    .call()
```

## Reference Files

### 📖 官方文档参考
- **Moqui Framework**: 企业应用开发框架
- **实体模型**: 数据建模和关系管理
- **服务架构**: RESTful API 和业务逻辑
- **屏幕组件**: UI 开发和表单处理

### 📁 本地项目文档

#### 01-guides/ - 开发指南
- `development-setup.md` - 开发环境搭建
- `debugging-methodology.md` - 调试方法论
- `ai-integration-guide.md` - AI集成开发指南
- `deployment-guide.md` - 生产环境部署

#### 02-design/ - 系统设计
- **API设计**: AI服务、Telegram Bot、供需平台API
- **架构设计**: 多模态AI架构、平台集成架构
- **数据设计**: 实体模型、数据流设计
- **工作流设计**: 供需撮合、项目管理流程

#### 03-tasks/ - 项目任务
- **Phase 1**: Telegram MVP实现
- **基础设施升级**: Vue3+Quasar2、JWT认证、MCP调试

#### 05-reports/ - 技术报告
- 技术实现总结
- 阶段完成报告
- 性能分析报告

## 常见开发模式

### 1. 创建新的供需实体
1. 定义实体模型 (entities/*.xml)
2. 创建相关服务 (services/*.xml)
3. 实现屏幕界面 (screen/*.xml)
4. 集成Telegram Bot命令

### 2. AI功能集成
1. 配置智谱AI服务
2. 实现多模态消息处理
3. 集成智能匹配算法
4. 优化响应速度

### 3. 认证和安全
1. JWT令牌管理
2. 权限控制配置
3. 安全策略实施
4. API接口保护

## 开发工具和调试

### Chrome MCP 调试
- MCP协议调试工具链
- 实时日志监控
- 性能分析

### Vue3 + Quasar2 开发
- 组件开发模式
- 状态管理
- 路由配置
- UI组件库

## 最佳实践

1. **代码组织**: 按业务模块组织代码结构
2. **服务设计**: RESTful API设计原则
3. **数据建模**: 实体关系合理设计
4. **性能优化**: 查询优化和缓存策略
5. **安全考虑**: 输入验证和权限控制
6. **文档维护**: 与代码同步更新

## 故障排除

### 常见问题
- JWT认证失败
- AI服务调用异常
- Telegram Bot响应超时
- 数据库连接问题
- Vue组件渲染错误

### 调试流程
1. 检查日志文件
2. 使用MCP调试工具
3. 验证配置文件
4. 测试API接口
5. 前端控制台检查

## 资源链接

- **项目文档**: `/Users/demo/Workspace/moqui/docs/`
- **组件文档**: `runtime/component/*/docs/`
- **进度日志**: `docs/progress-log.md`
- **技术报告**: `docs/05-reports/`

---

**最后更新**: 2025-11-01
**技能版本**: v2.0 (包含本地项目文档)
**维护者**: Claude Code AI Assistant

此技能结合了 Moqui Framework 官方文档和智能供需平台项目的实际开发经验，为项目开发提供全面支持。
